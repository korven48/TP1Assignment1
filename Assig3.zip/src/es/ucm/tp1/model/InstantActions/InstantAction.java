package es.ucm.tp1.model.InstantActions;

import es.ucm.tp1.model.Game;

public interface InstantAction {
	void execute(Game game);
}
