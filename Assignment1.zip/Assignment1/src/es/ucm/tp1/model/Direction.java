package es.ucm.tp1.model;

public enum Direction {
	UP,
	DOWN,
	FORWARD,
	NONE
}
